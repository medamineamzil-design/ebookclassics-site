/* Shared navigation and live catalogue totals. Uses the site's existing account flows. */
(function(){
 const home=document.getElementById('view-home');
 const summary=document.createElement('section');summary.className='library-summary';home.append(summary);
 const header=document.querySelector('header.site');
 const actions=document.createElement('div');actions.className='library-account-tools';
 // Move the original controls, preserving listeners, translations and account state.
 ['langSwitch','accountChip'].forEach(id=>{const el=document.getElementById(id);if(el)actions.append(el)});
 const auth=header.querySelector('.topbar-auth');if(auth)actions.append(auth);
 header.append(actions);
 function refresh(){
  const available=BOOKS.filter(b=>bookAvailable(b)&&BOOK_EXTRA[hostedSlug(b)]);
  const languages=new Set();available.forEach(b=>Object.keys(bookEditions(b)||{}).forEach(l=>languages.add(l)));
  // Verified catalogue snapshot (2026-10-05), used while the remote manifests load.
  const audios=Object.keys(AUDIO||{}).length?available.reduce((n,b)=>n+Object.keys(AUDIO[hostedSlug(b)]||{}).length,0):149;
  const languageCount=EDITIONS?languages.size:7;
  const fr=state.uiLang==='FR';
  summary.innerHTML=`<h2>${fr?'La bibliothèque en quelques chiffres':'Your library at a glance'}</h2><div class="library-totals"><div><strong>${available.length}</strong><span>${t('hx.statBooks')}</span></div><div><strong>${audios}</strong><span>${t('hx.statAudio')}</span></div><div><strong>${languageCount}</strong><span>${t('hx.statLangs')}</span></div></div><p>${fr?'Des classiques à lire, à écouter et à retrouver chaque jour.':'Classic stories to read, listen to and rediscover every day.'}</p>`;
  // The original room illustration stays intact; a readable translation is available below it.
  const room=document.querySelector('.library-original-home');
  if(room)room.setAttribute('aria-label',fr?'À découvrir aujourd’hui':'Discover today');
 }
 const oldHome=renderHome;renderHome=function(){oldHome();refresh()};
 const oldLang=applyUILang;applyUILang=function(code,opts){oldLang(code,opts);refresh()};
 updateAuthHeaderVisibility();refresh();
 const oldAuth=openAuth;openAuth=function(mode){oldAuth(mode);let notice=document.getElementById('libraryAccountNotice');if(!notice){notice=document.createElement('p');notice.id='libraryAccountNotice';notice.className='library-account-notice';document.getElementById('authIntro').after(notice)}notice.hidden=!!dbNS;notice.textContent=state.uiLang==='FR'?'Le service de comptes est actuellement indisponible. La création de compte et la connexion seront accessibles après son activation. Vos favoris et votre progression restent disponibles sur cet appareil.':'The account service is currently unavailable. Registration and sign-in will become available once it is activated. Your favorites and reading progress remain available on this device.';document.querySelectorAll('#signUpForm input,#signInForm input,#signUpForm button,#signInForm button').forEach(el=>el.disabled=!dbNS)};
 // Client-side view links are deep-linkable, including return from book pages.
 function route(){if(location.hash==='#genres')showView('genres');if(location.hash==='#library')showView('library');if(location.hash==='#catalog')showView('catalog');if(location.hash==='#signin')openAuth('signin');if(location.hash==='#signup')openAuth('signup')}
 window.addEventListener('hashchange',route);route();
 document.documentElement.classList.add('library-ready');
})();
