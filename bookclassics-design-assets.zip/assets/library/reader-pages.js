/* Reflowable page reader: real selectable paragraphs, optional scrolling mode. */
(function(){
const content=document.getElementById('readerContent'),body=document.getElementById('readerBody'),modal=document.getElementById('readerModal');
let page=0,count=1,step=1,column=1,active=false,layoutTimer,animationTimer,turnAnimation,turnStage;
const controls=document.createElement('div');controls.className='library-reader-controls';controls.innerHTML='<button type="button" data-reader-action="previous">←</button><span class="library-page-count" aria-live="polite"></span><button type="button" data-reader-action="next">→</button><button type="button" data-reader-action="mode"></button>';
body.after(controls);
const lang=()=>state.uiLang==='FR';
function update(){controls.querySelector('[data-reader-action=previous]').disabled=page===0||!active;controls.querySelector('[data-reader-action=next]').disabled=page>=count-1||!active;controls.querySelector('[data-reader-action=previous]').setAttribute('aria-label',lang()?'Pages précédentes':'Previous pages');controls.querySelector('[data-reader-action=next]').setAttribute('aria-label',lang()?'Pages suivantes':'Next pages');controls.querySelector('.library-page-count').textContent=active?`${lang()?'Page':'Page'} ${page+1} / ${count}`:'';controls.querySelector('[data-reader-action=mode]').textContent=active?(lang()?'Lecture en défilement':'Scrolling view'):(lang()?'Livre à pages':'Page view')}
function charColumn(p,offset){const text=p.firstChild;if(!text||text.nodeType!==3)return 0;const r=document.createRange();r.setStart(text,Math.min(offset,Math.max(0,text.length-1)));r.setEnd(text,Math.min(offset+1,text.length));return Math.max(0,Math.floor((r.getBoundingClientRect().left-content.getBoundingClientRect().left+content.scrollLeft+2)/column))}
function anchor(){const paras=readerContentParagraphEls();const firstColumn=Math.round(page*step/column);for(let i=0;i<paras.length;i++){const p=paras[i],text=p.firstChild;if(!text||text.nodeType!==3)continue;if(charColumn(p,text.length-1)<firstColumn)continue;let low=0,high=text.length-1;while(low<high){const mid=Math.floor((low+high)/2);if(charColumn(p,mid)<firstColumn)low=mid+1;else high=mid}return {index:i,offset:low,total:paras.length,savedAt:Date.now()}}return {index:0,offset:0,total:paras.length,savedAt:Date.now()}}
function save(){if(!active)return oldSave();if(!readerBookId||!readerIsFullText||content.hidden)return;const map=loadReaderProgressMap();map[readerProgressKey(readerBookId,bdSelectedLangCode)]=anchor();saveReaderProgressMap(map)}
function saved(){return loadReaderProgressMap()[readerProgressKey(readerBookId,bdSelectedLangCode)]}
function cancelTurn(){if(turnAnimation)turnAnimation.cancel();turnAnimation=null;if(turnStage)turnStage.remove();turnStage=null;modal.classList.remove('library-turning')}
function leafFace(side,position){
 const face=document.createElement('div');face.className='library-leaf-face';
 const clone=content.cloneNode(true);clone.removeAttribute('id');clone.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));clone.classList.add('library-leaf-copy');clone.setAttribute('aria-hidden','true');clone.inert=true;
 clone.style.width=content.clientWidth+'px';clone.style.height=content.clientHeight+'px';clone.style.left=(-side*column)+'px';clone.style.top='0';clone.style.padding='0';
 face.append(clone);return {face,clone,position};
}
function go(n,animate=false){
 const target=Math.max(0,Math.min(count-1,n));if(turnAnimation||target===page){if(!turnAnimation){content.scrollLeft=page*step;update();save()}return}
 const previous=page,forward=target>previous,two=content.clientWidth>=760;
 const motion=animate&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
 let front,back,leaf;
 if(motion){
  const r=content.getBoundingClientRect(),br=body.getBoundingClientRect(),width=two?column-48:content.clientWidth;
  turnStage=document.createElement('div');turnStage.className='library-turn-stage';turnStage.setAttribute('aria-hidden','true');
  Object.assign(turnStage.style,{left:(r.left-br.left+content.clientLeft)+'px',top:(r.top-br.top+content.clientTop)+'px',width:content.clientWidth+'px',height:content.clientHeight+'px'});
  leaf=document.createElement('div');leaf.className='library-turn-leaf'+(forward?'':' backward');leaf.style.width=width+'px';leaf.style.left=(two&&forward?column:0)+'px';
  front=leafFace(two&&forward?1:0,previous*step);back=leafFace(two&&!forward?1:0,target*step);back.face.classList.add('back');
  leaf.append(front.face,back.face);turnStage.append(leaf);body.append(turnStage);front.clone.scrollLeft=front.position;back.clone.scrollLeft=back.position;modal.classList.add('library-turning');
 }
 page=target;content.scrollLeft=page*step;update();save();
 if(motion){turnAnimation=leaf.animate([{transform:'rotateY(0deg)'},{transform:`rotateY(${forward?-85:85}deg)`,offset:.5},{transform:`rotateY(${forward?-180:180}deg)`}],{duration:850,easing:'cubic-bezier(.35,.08,.22,1)',fill:'forwards'});turnAnimation.onfinish=cancelTurn;}
}
function layout(position){cancelTurn();if(!active||content.hidden)return;const width=content.clientWidth,height=body.clientHeight-parseFloat(getComputedStyle(body).paddingTop)-parseFloat(getComputedStyle(body).paddingBottom)-content.offsetHeight+content.clientHeight;if(width<1||height<80)return;const columns=width>=760?2:1;const gap=columns===2?48:24;const colWidth=(width-gap*(columns-1))/columns;content.style.height=Math.max(80,body.clientHeight-parseFloat(getComputedStyle(body).paddingTop)-parseFloat(getComputedStyle(body).paddingBottom))+'px';content.style.columnGap=gap+'px';content.style.columnWidth=colWidth+'px';column=colWidth+gap;step=column*columns;requestAnimationFrame(()=>{count=Math.max(1,Math.ceil((content.scrollWidth+gap)/step));const p=position&&readerContentParagraphEls()[position.index];page=p?Math.floor(charColumn(p,position.offset||0)/columns):Math.min(page,count-1);go(page)})}
function mode(pages){cancelTurn();const position=active?anchor():saved();active=pages;modal.classList.toggle('library-page-mode',active);if(active){body.scrollTop=0;layout(position)}else{content.style.height='';content.style.columnGap='';content.style.columnWidth='';content.scrollLeft=0;const p=position&&readerContentParagraphEls()[position.index];if(p)p.scrollIntoView({block:'start'});update()}}

const related=document.createElement('section');related.className='library-reader-related';related.hidden=true;controls.after(related);
function recommend(id){
 const current=bookById(id);if(!current){related.hidden=true;return}
 const candidates=BOOKS.filter(b=>b.id!==id&&bookAvailable(b)&&BOOK_EXTRA[hostedSlug(b)]&&(b.author===current.author||b.cat===current.cat));
 candidates.sort((a,b)=>(b.author===current.author)-(a.author===current.author));
 const picks=candidates.slice(0,8);related.hidden=!picks.length;
 related.innerHTML=`<button type="button" class="library-reader-related-toggle" aria-expanded="${!related.classList.contains('collapsed')}">${lang()?'Suggestions':'Suggestions'}</button><h2>${lang()?'Du même auteur · Dans le même rayon':'Same author · Same shelf'}</h2><div class="library-related-row">${picks.map(b=>`<a class="library-related-book" href="${hxBookHref(b)}">${hxCover(b)}<span>${escapeHtml(b.title)}</span><small>${escapeHtml(b.author)}</small></a>`).join('')}</div>`;
 related.querySelector('button').onclick=()=>{const position=active?anchor():saved();related.classList.toggle('collapsed');related.querySelector('button').setAttribute('aria-expanded',!related.classList.contains('collapsed'));requestAnimationFrame(()=>layout(position))};
}
const oldClose=closeReader;closeReader=function(){cancelTurn();oldClose()};

const oldSave=saveCurrentReaderProgress;saveCurrentReaderProgress=save;
const oldRestore=restoreReaderProgress;restoreReaderProgress=function(){if(active)layout(saved());else oldRestore()};
const oldOpen=openReader;openReader=async function(id){if(active)save();await oldOpen(id);recommend(id);if(modal.classList.contains('open')&&!content.hidden){content.dir='ltr';page=0;mode(true)}};
const oldToggle=toggleReaderSettings;toggleReaderSettings=function(){const position=saved();oldToggle();if(active)requestAnimationFrame(()=>layout(position))};
const oldPrefs=applyReaderPrefsToDom;applyReaderPrefsToDom=function(){const position=active&&!content.hidden?anchor():saved();oldPrefs();if(active&&!content.hidden)requestAnimationFrame(()=>layout(position))};
controls.querySelector('[data-reader-action=previous]').onclick=()=>go(page-1,true);controls.querySelector('[data-reader-action=next]').onclick=()=>go(page+1,true);controls.querySelector('[data-reader-action=mode]').onclick=()=>mode(!active);
modal.addEventListener('keydown',e=>{if(!active||!modal.classList.contains('open')||/INPUT|SELECT|TEXTAREA|BUTTON/.test(e.target.tagName))return;if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();go(page+(e.key==='ArrowRight'?1:-1),true)}});
let touch;content.addEventListener('touchstart',e=>{touch=[e.changedTouches[0].clientX,e.changedTouches[0].clientY]},{passive:true});content.addEventListener('touchend',e=>{if(!active||!touch)return;const dx=e.changedTouches[0].clientX-touch[0],dy=e.changedTouches[0].clientY-touch[1];if(Math.abs(dx)>60&&Math.abs(dx)>Math.abs(dy)*1.5)go(page+(dx<0?1:-1),true);touch=null},{passive:true});
window.addEventListener('resize',()=>{if(!active)return;const position=saved();clearTimeout(layoutTimer);layoutTimer=setTimeout(()=>layout(position),120)});
const oldHighlight=highlightReaderParagraph;highlightReaderParagraph=function(i){oldHighlight(i);if(active){const p=readerContentParagraphEls()[i];if(p)go(Math.floor(charColumn(p,0)/(content.clientWidth>=760?2:1)))}};
new MutationObserver(()=>{if(!content.hidden&&modal.classList.contains('open')&&!active)mode(true)}).observe(content,{attributes:true,attributeFilter:['hidden']});update();
})();
