/* Presentation layer; existing catalogue, editions and account functions stay authoritative. */
(function(){
const copy={EN:{home:'Enter your library',lead:'Stories to discover. Books to explore.',genres:'Choose your shelf',intro:'Explore the classics according to your interests.',explore:'Explore genres',all:'See all books',shelf:'Explore this shelf',shelves:'Shelves',grid:'Grid',back:'All genres'},FR:{home:'Entrez dans votre bibliothèque',lead:'Des histoires à découvrir, des livres à feuilleter.',genres:'Choisissez votre rayon',intro:'Explorez les classiques selon vos envies.',explore:'Explorer les genres',all:'Voir tous les livres',shelf:'Explorer ce rayon',shelves:'Étagères',grid:'Grille',back:'Tous les genres'}};
const $=id=>document.getElementById(id);const words=()=>copy[state.uiLang]||copy.EN;
const genres=document.createElement('section');genres.id='view-genres';genres.className='view library-genres';genres.hidden=true;$('view-home').after(genres);
const nav=document.createElement('button');nav.className='navlink';nav.id='nav-genres';nav.onclick=()=>showView('genres');$('nav-home').after(nav);
const head=document.createElement('div');head.className='library-catalog-head';$('view-catalog').querySelector('.section-title').replaceWith(head);
function decorate(){
 const w=words();nav.textContent=w.back;
 const h=document.querySelector('.hx-hero h1');h.removeAttribute('data-i18n');h.textContent=w.home;$('hxLead').textContent=w.lead;
 const actions=document.querySelectorAll('.hx-actions a');actions[0].removeAttribute('data-i18n');actions[0].textContent=w.explore;actions[0].href='#genres';actions[0].onclick=()=>{showView('genres');return false};actions[1].removeAttribute('data-i18n');actions[1].textContent=w.all;actions[1].href='/books/';actions[1].onclick=()=>{state.cat=null;state.page=1;renderCatBar();showView('catalog');return false};
 genres.innerHTML=`<div class="library-heading"><p>${t('nav.home')} / ${w.back}</p><h1>${w.genres}</h1><p>${w.intro}</p></div><div class="library-genre-grid">${CATEGORIES.map(c=>`<a class="library-genre-card" href="/books/#${c.slug}" data-genre="${c.slug}"><img src="/genres/${c.slug}.jpg" alt="" loading="lazy" width="600" height="375"><div><h2>${catLabel(c.slug)}</h2><span>${t('hx.booksN',{n:BOOKS.filter(b=>b.cat===c.slug&&bookAvailable(b)&&BOOK_EXTRA[hostedSlug(b)]).length})}</span><strong>${w.shelf} →</strong></div></a>`).join('')}</div><a class="library-browse btn btn-primary" href="/books/">${w.all} →</a>`;
 genres.querySelectorAll('[data-genre]').forEach(a=>a.onclick=()=>{selectGenre(a.dataset.genre);return false});genres.querySelector('.library-browse').onclick=()=>{state.cat=null;state.page=1;showView('catalog');return false};catalogHeading();
}
function catalogHeading(){const w=words();head.dataset.genre=state.cat||'';head.style.setProperty('--genre-image',state.cat?`url('/genres/${state.cat}.jpg')`:'none');head.innerHTML=`<a href="#genres">${w.back}</a><h1>${state.cat?catLabel(state.cat):w.all}</h1><p>${w.intro}</p><div class="library-views"><button data-layout="shelves" aria-pressed="${document.body.dataset.catalogLayout!=='grid'}">${w.shelves}</button><button data-layout="grid" aria-pressed="${document.body.dataset.catalogLayout==='grid'}">${w.grid}</button></div>`;head.querySelector('a').onclick=()=>{showView('genres');return false};head.querySelectorAll('button').forEach(b=>b.onclick=()=>{document.body.dataset.catalogLayout=b.dataset.layout;catalogHeading()})}
const oldView=showView;showView=function(name){oldView(name);document.body.dataset.libraryView=name;nav.setAttribute('aria-current',name==='genres'?'true':'false');if(name==='genres')decorate();if(name==='catalog')catalogHeading()};
const oldHome=renderHome;renderHome=function(){oldHome();decorate()};
const oldCatalog=renderCatalog;renderCatalog=function(){oldCatalog();catalogHeading()};
$('nav-catalog').onclick=()=>{state.cat=null;state.page=1;renderCatBar();showView('catalog')};
const oldBar=renderCatBar;renderCatBar=function(){oldBar();const all=$('catBar').firstElementChild;if(all)all.onclick=()=>showView('genres')};
renderCatBar();decorate();document.body.dataset.libraryView=state.view||'home';
if(location.hash==='#genres')showView('genres');window.addEventListener('hashchange',()=>{if(location.hash==='#genres')showView('genres')});
})();

/* A visitor-controlled table: no automatic motion while choosing a book. */
(function(){
 function table(){
  const track=document.getElementById('mxTrack'),inner=document.getElementById('mxShelfIn');
  if(!track||!inner)return;
  if(window.gsap){gsap.killTweensOf(inner);gsap.set(inner,{clearProps:'transform'});}
  document.getElementById('mxShelf').classList.remove('loop');
  const move=direction=>track.scrollBy({left:direction*Math.max(180,track.clientWidth*.75),behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  document.getElementById('mxPrev').onclick=()=>move(-1);document.getElementById('mxNext').onclick=()=>move(1);
  document.querySelectorAll('#hxStart .mx-item:not(.mx-clone)').forEach(a=>{if(!a.querySelector('.library-open')){const label=document.createElement('span');label.className='library-open';label.textContent=state.uiLang==='FR'?'Ouvrir →':'Open →';a.append(label)}});
 }
 const oldShelf=mxRenderShelf;mxRenderShelf=function(list){oldShelf(list);table()};
 if(window.bcMotion){const home=bcMotion.home,view=bcMotion.view;bcMotion.home=function(){home();table()};bcMotion.view=function(name){view(name);setTimeout(table,30)};bcMotion.shelf=table;}
 document.addEventListener('DOMContentLoaded',table);window.addEventListener('load',table);table();
})();

/* Original artwork kept byte for byte. Only the daily book faces may change. */
(function(){
 const home=document.getElementById('view-home'),room=document.createElement('section');
 room.className='library-original-home';room.setAttribute('aria-label','BookClassics — À découvrir aujourd’hui');
 room.innerHTML='<img class="library-original-art" src="/assets/library/home-original.png" width="1536" height="1024" alt="Bibliothèque BookClassics : Entrez dans votre bibliothèque. Des histoires à découvrir, des livres à feuilleter."><div class="library-original-links"></div><div class="library-daily-books"></div><nav class="library-mobile-menu" aria-label="Navigation de la bibliothèque"></nav>';
 home.prepend(room);
 const links=room.querySelector('.library-original-links'),books=room.querySelector('.library-daily-books');
 function action(label,area,view){const a=document.createElement('a');a.className='library-art-link '+area;a.href=view==='catalog'?'/books/':'#'+view;a.setAttribute('aria-label',label);a.innerHTML='<span class="library-sr-only">'+label+'</span>';a.onclick=e=>{e.preventDefault();if(view==='catalog'){state.cat=null;state.page=1;renderCatBar()}showView(view);if(area==='original-search')document.getElementById('searchInput').focus()};links.append(a);return a}
 action('BookClassics — Accueil','original-brand','home');action('Accueil','original-home','home');action('Tous les genres','original-genres','genres');action('Mes livres','original-library','library');action('Rechercher un livre','original-search','catalog');action('Explorer les genres','original-explore','genres');action('Voir tous les livres','original-catalog','catalog');
 const mobile=room.querySelector('.library-mobile-menu');for(const [label,view] of [['Accueil','home'],['Tous les genres','genres'],['Mes livres','library'],['Rechercher','catalog']]){const a=document.createElement('a');a.href='#'+view;a.textContent=label;a.onclick=e=>{e.preventDefault();showView(view)};mobile.append(a)}
 const featured=['dracula','treasure-island','alice-s-adventures-in-wonderland','pride-and-prejudice','les-miserables'];
 const positions=[[11.46,12.96],[27.80,12.96],[43.10,13.67],[59.05,12.96],[74.35,13.28]];
 const dayKey=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Casablanca',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]).reduce((a,[k,v])=>(a[k]=v,a),{});
 function dateKey(){const d=dayKey();return `${d.year}-${d.month}-${d.day}`}
 function choose(date){const offset=Math.floor((Date.parse(date+'T12:00:00Z')-Date.parse('2026-10-05T12:00:00Z'))/86400000);const available=BOOKS.filter(b=>bookAvailable(b)&&BOOK_EXTRA[hostedSlug(b)]);if(offset===0)return featured.map(slug=>available.find(b=>hostedSlug(b)===slug)).filter(Boolean);return CATEGORIES.map(c=>{const pool=available.filter(b=>b.cat===c.slug&&!featured.includes(hostedSlug(b)));return pool[((offset-1)%pool.length+pool.length)%pool.length]}).filter(Boolean).slice(0,5)}
 let lastDate='';
 function refresh(){const date=dateKey();lastDate=date;const picked=choose(date);room.dataset.selectionDate=date;books.innerHTML='';picked.forEach((b,i)=>{const a=document.createElement('a');a.className='library-daily-book';a.href=hxBookHref(b);a.setAttribute('aria-label',`${b.title} — ${b.author} : ouvrir le livre`);a.style.left=positions[i][0]+'%';a.style.width=positions[i][1]+'%';a.dataset.bookId=b.id;if(date!=='2026-10-05')a.innerHTML=hxCover(b);const label=document.createElement('span');label.className='library-sr-only';label.textContent=b.title+' — '+b.author;a.append(label);books.append(a)});mobile.querySelectorAll('.library-mobile-book').forEach(a=>a.remove());picked.forEach(b=>{const a=document.createElement('a');a.className='library-mobile-book';a.href=hxBookHref(b);a.textContent=b.title;mobile.append(a)})}
 const render=renderHome;renderHome=function(){render();refresh()};refresh();
 // A new collection every calendar day in Morocco, also on an already open page.
 setInterval(()=>{if(dateKey()!==lastDate)refresh()},60000);document.addEventListener('visibilitychange',()=>{if(!document.hidden&&dateKey()!==lastDate)refresh()});
})();
