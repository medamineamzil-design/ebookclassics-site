/* Presentation layer; existing catalogue, editions and account functions stay authoritative. */
(function(){
const copy={EN:{home:'Enter your library',lead:'Stories to discover. Books to explore.',genres:'Choose your shelf',intro:'Explore the classics according to your interests.',explore:'Explore genres',all:'See all books',shelf:'Explore this shelf',shelves:'Shelves',grid:'Grid',back:'All genres'},FR:{home:'Entrez dans votre bibliothèque',lead:'Des histoires à découvrir, des livres à feuilleter.',genres:'Choisissez votre rayon',intro:'Explorez les classiques selon vos envies.',explore:'Explorer les genres',all:'Voir tous les livres',shelf:'Explorer ce rayon',shelves:'Étagères',grid:'Grille',back:'Tous les genres'}};
const $=id=>document.getElementById(id);const words=()=>copy[state.uiLang]||copy.EN;
const genres=document.createElement('section');genres.id='view-genres';genres.className='view library-genres';genres.hidden=true;$('view-home').after(genres);
const nav=document.createElement('button');nav.className='navlink';nav.id='nav-genres';nav.onclick=()=>showView('genres');$('nav-home').after(nav);
const head=document.createElement('div');head.className='library-catalog-head';$('view-catalog').querySelector('.section-title').replaceWith(head);
function decorate(){
 const w=words();nav.textContent=w.back;
 const h=document.querySelector('.hx-hero h1');h.removeAttribute('data-i18n');h.textContent=w.home;$('hxLead').textContent=w.lead;
 const actions=document.querySelectorAll('.hx-actions a');actions[0].removeAttribute('data-i18n');actions[0].textContent=w.explore;actions[0].href='#genres';actions[0].onclick=()=>{showView('genres');return false};actions[1].removeAttribute('data-i18n');actions[1].textContent=w.all;actions[1].href='/books/';actions[1].onclick=()=>{state.cat=null;state.page=1;renderCatBar();showView('catalog');return false};
 genres.innerHTML=`<div class="library-heading"><p>${t('nav.home')} / ${w.back}</p><h1>${w.genres}</h1><p>${w.intro}</p></div><div class="library-genre-grid">${CATEGORIES.map(c=>`<a class="library-genre-card" href="/books/#${c.slug}" data-genre="${c.slug}"><img src="/genres/${c.slug}.jpg" alt="" loading="lazy" width="600" height="375"><div><h2>${catLabel(c.slug)}</h2><span>${t('hx.booksN',{n:BOOKS.filter(b=>b.cat===c.slug&&bookAvailable(b)&&BOOK_EXTRA[hostedSlug(b)]).length})}</span><strong>${w.shelf} →</strong></div></a>`).join('')}</div><a class="library-browse btn btn-primary" href="/books/">${w.all} →</a>`;
 genres.querySelectorAll('[data-genre]').forEach(a=>a.onclick=()=>{selectGenre(a.dataset.genre);return false});genres.querySelector('.library-browse').onclick=()=>{state.cat=null;state.page=1;showView('catalog');return false};catalogHeading();
}
function catalogHeading(){const w=words();head.dataset.genre=state.cat||'';head.style.setProperty('--genre-image',state.cat?`url('/genres/${state.cat}.jpg')`:'none');head.innerHTML=`<a href="#genres">${w.back}</a><h1>${state.cat?catLabel(state.cat):w.all}</h1><p>${w.intro}</p><div class="library-views"><button data-layout="shelves" aria-pressed="${document.body.dataset.catalogLayout!=='grid'}">${w.shelves}</button><button data-layout="grid" aria-pressed="${document.body.dataset.catalogLayout==='grid'}">${w.grid}</button></div>`;head.querySelector('a').onclick=()=>{showView('genres');return false};head.querySelectorAll('button').forEach(b=>b.onclick=()=>{document.body.dataset.catalogLayout=b.dataset.layout;catalogHeading()})}
const oldView=showView;showView=function(name){oldView(name);document.body.dataset.libraryView=name;nav.setAttribute('aria-current',name==='genres'?'true':'false');if(name==='genres')decorate();if(name==='catalog')catalogHeading()};
const oldHome=renderHome;renderHome=function(){oldHome();decorate()};
const oldCatalog=renderCatalog;renderCatalog=function(){oldCatalog();catalogHeading()};
$('nav-catalog').onclick=()=>{state.cat=null;state.page=1;renderCatBar();showView('catalog')};
const oldBar=renderCatBar;renderCatBar=function(){oldBar();const all=$('catBar').firstElementChild;if(all)all.onclick=()=>showView('genres')};
renderCatBar();decorate();document.body.dataset.libraryView=state.view||'home';
if(location.hash==='#genres')showView('genres');window.addEventListener('hashchange',()=>{if(location.hash==='#genres')showView('genres')});
})();
