# BookClassics — nouvelle présentation

Branche : design/immersive-library. Le site et les pages de livres utilisent une feuille de style partagée. La couche de présentation ajoute une page des cinq genres et le choix Étagères/Grille sans remplacer les fonctions existantes du catalogue.

Accueil : décor de la maquette approuvée, nettoyé de son interface incrustée ; les textes et boutons sont de vrais éléments HTML. Genres : fond distinct d’une allée de bibliothèque. Les cinq illustrations déjà présentes dans /genres sont réutilisées.

Les nouveaux libellés sont disponibles en français et anglais, avec repli anglais pour les autres langues ; les traductions existantes des genres et du catalogue continuent de fonctionner. Le lecteur ajoute une pagination du texte adaptable : deux pages sur grand écran, une page sur téléphone, flèches, clavier, balayage, transition courte, retour au défilement et mémorisation d’une position dans le texte. Il conserve les paragraphes sélectionnables et les réglages existants. La transition est une animation légère ; elle ne simule pas une feuille 3D déformable.

## Lancer

À la racine : `python3 -m http.server 8765`, puis ouvrir http://localhost:8765. Les URLs de téléchargement des livres restent celles du dépôt ebookclassics-files. Vérifier les éditions et audios sur une prévisualisation connectée avant fusion.

## Images

Générées avec l’outil intégré de génération d’images, puis compressées en WebP :
- assets/library/home-background.webp : conserver la salle historique, fenêtres cintrées, tables et lumière dorée de la maquette ; retirer navigation, textes, panneaux, boutons et livres superposés pour obtenir un fond photographique sans interface.
- assets/library/genres-background.webp : photographie panoramique d’une allée intime, rayonnages en chêne, murs crème, fenêtre rectangulaire et lampes en laiton ; sans personnages, texte ou interface.

Pour revenir à l’apparence précédente, revenir au commit précédent via Git. Ne pas remplacer ni supprimer le dépôt des fichiers des livres.

Vérifications : navigateur Chromium local, accueil/genres/rayon/grille/fiches, écran de 390 px sans débordement, langues FR/EN/AR et lecteur testé avec un texte de fixture pour navigation et reprise après changement de taille. Les fichiers distants et l’authentification doivent être vérifiés sur la prévisualisation connectée.
