# BookClassics — nouvelle présentation

Branche : design/immersive-library. Le site et les pages de livres utilisent une feuille de style partagée. La couche de présentation ajoute une page des cinq genres et le choix Étagères/Grille sans remplacer les fonctions existantes du catalogue.

Accueil : décor de la maquette approuvée, nettoyé de son interface incrustée ; les textes et boutons sont de vrais éléments HTML. Genres : fond distinct d’une allée de bibliothèque. Les cinq illustrations déjà présentes dans /genres sont réutilisées.

Les nouveaux libellés sont disponibles en français et anglais, avec repli anglais pour les autres langues ; les traductions existantes des genres et du catalogue continuent de fonctionner. Le lecteur ajoute une pagination du texte adaptable : deux pages sur grand écran, une page sur téléphone, flèches, clavier, balayage, transition courte, retour au défilement et mémorisation d’une position dans le texte. Il conserve les paragraphes sélectionnables et les réglages existants. La transition est une animation légère ; elle ne simule pas une feuille 3D déformable.

## Lancer

À la racine : `python3 -m http.server 8765`, puis ouvrir http://localhost:8765. Les URLs de téléchargement des livres restent celles du dépôt ebookclassics-files. Vérifier les éditions et audios sur une prévisualisation connectée avant fusion.

## Images

Générées avec l’outil intégré de génération d’images, puis compressées en WebP :
- assets/library/home-background.webp : conserver la salle historique, fenêtres cintrées, tables et lumière dorée de la maquette ; retirer navigation, textes, panneaux, boutons et livres superposés pour obtenir un fond photographique sans interface.
- assets/library/genres-background.webp : photographie panoramique d’une allée intime, rayonnages en chêne, murs crème, fenêtre rectangulaire et lampes en laiton ; sans personnages, texte ou interface.

Pour revenir à l’apparence précédente, revenir au commit précédent via Git. Ne pas remplacer ni supprimer le dépôt des fichiers des livres.

Vérifications : navigateur Chromium local, accueil/genres/rayon/grille/fiches, écran de 390 px sans débordement, langues FR/EN/AR et lecteur testé avec un texte de fixture pour navigation et reprise après changement de taille. Les fichiers distants et l’authentification doivent être vérifiés sur la prévisualisation connectée.

## Immersive presentation — revision 3
- Home selection uses the existing catalogue covers on a wooden table in the library room. Native horizontal scrolling, next/previous buttons, touch scrolling, and visible Open links; no forced automatic motion.
- Reader has a paper spread, spine and page stack, with a two-sided 3D leaf animation, shadow and folded corner. This is a visual page-turn simulation, not a physical mesh deformation. Reduced-motion users get immediate page changes.
- Reader suggestions prioritize books by the same author, then books in the same category, using current catalogue availability. Collapsible to give reading more space.
- Static book recommendation grids are displayed as horizontal wooden shelves.
- Checked actual Chromium: carousel moves, front/back faces, backwards turn, reduced motion, recommendations, mobile overflow, font reflow and position preservation. Reader test text is a fixture, not a replacement for book contents.

## Original opening artwork — revision 4
- `home-original.png` is a byte-for-byte copy of the user-selected source. The generated preview is not substituted for the original.
- The opening uses this complete artwork, preserving the pictured menu, text, furniture, light and all room details. Accessible links align with its navigation, main actions and five opening buttons.
- No home carousel. Five static book positions: on 2026-10-05 use the exact five illustrated original titles; subsequent Morocco calendar days select one available title per category, deterministically. Only the book faces change. An already open page refreshes its selection within one minute of the date change.
- On small screens the intact image scales down; an accessible navigation and title list underneath provides usable touch targets.
- Verified original byte equality, five unique titles, next-day change, five categories on later days, genre and library navigation, mobile overflow, no browser errors.
